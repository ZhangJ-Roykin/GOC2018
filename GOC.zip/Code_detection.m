function  Code_detection(Car_Set,Distance,Time,Delivery_P)

    Route=[Car_Set.Route];
    Route(Route==0)=[];
    Route(Delivery_P(Route+1,2)==4)=[];
    Route=unique(Route);
    if length(Route)==(length(Distance)-1-100)
    else
         length(Route)
         fprintf('�̼�δ����');
    end
     for i=1:length(Car_Set)
        Route=Car_Set(i).Route;
        Current_Time=Car_Set(i).Departure_Time;
        Return_Time=Car_Set(i).Return_Time;
        Current_Time=datenum(['0/0/0 ',Current_Time]);
        Return_Time=datenum(['0/0/0 ',Return_Time]);
        ele_Times=0;
         Wait_Cost=0;
         Save_W=0;
         Save_V=0;
         Distance_cost=0;
        for j=1:length(Route)
            if Route(j)==0 & j>1
                Distance_cost=Distance_cost+Distance(Route(j-1)+1,Route(j)+1);   
            end

            if Route(j)==0
                Weight=Car_Set(i).Weight;
                Volume=Car_Set(i).Volume;
                if Car_Set(i).Car_model==1
                    eles=100000;
                else
                     eles=120000;
                end
                if j>1
                     Current_Time=Current_Time+Time(Route(j-1)+1,Route(j)+1)+1.0/24;
                end 
                if j<length(Route) & j>1
                     Wait_Cost=Wait_Cost+24;
                end
            elseif Delivery_P(Route(j)+1,2)==4
                ele_Times=ele_Times+1;
                if Car_Set(i).Car_model==1
                    eles=100000;
                else
                     eles=120000;
                end
                Distance_cost=Distance_cost+Distance(Route(j-1)+1,Route(j)+1);   
                  Current_Time=Current_Time+Time(Route(j-1)+1,Route(j)+1)+0.5/24;
            else
                
                
                
                 if Delivery_P(Route(j)+1,2)==2
                          Weight=Weight-Delivery_P(Route(j)+1,5);
                          Volume=Volume-Delivery_P(Route(j)+1,6);
                  else
                            TRoute= Route(1:j);
                            TRoute=TRoute(Delivery_P(TRoute+1,2)==2);
                            TWeight1=sum(Delivery_P(TRoute+1,5));
                            TVolume1=sum(Delivery_P(TRoute+1,6));
                            
                             W=Delivery_P(Route(j)+1,5)-TWeight1+Save_W;
                             W(W<0)=0;
                             V=Delivery_P(Route(j)+1,6)-TVolume1+Save_V;
                             V(V<0)=0;
                             Weight=Weight-W;%ʣ�����ظ���
                             Volume= Volume-V;%ʣ���������

                             Save_W=Save_W+(Delivery_P(Route(j)+1,5)-W);
                            Save_V=Save_V+ (Delivery_P(Route(j)+1,6)-V);
                  end
                
            
                if Weight<0 || Volume<0
                    Weight
                    Volume
 
                    Car_Set(i).Route
                     fprintf('��������');
                end

                eles=eles-Distance(Route(j-1)+1,Route(j)+1);   
               Distance_cost=Distance_cost+Distance(Route(j-1)+1,Route(j)+1);   
                if eles<0
                    Car_Set(i).Route
                    fprintf('��������');
                end               

                Current_Time=Current_Time+Time(Route(j-1)+1,Route(j)+1);
                Wait_Time=Delivery_P(Route(j)+1,7)-Current_Time;
                Wait_Time(Wait_Time<0)=0;
                Wait_Cost=Wait_Cost+Wait_Time*24*24;
                Current_Time=Current_Time+Wait_Time;
                if Current_Time>Delivery_P(Route(j)+1,8) || Current_Time<Delivery_P(Route(j)+1,7)
                    Car_Set(i).Route 
                    fprintf('����ʱ���쳣');
                end
                Current_Time=Current_Time+ 0.5/24;
            end
        end
        Current_Time=Current_Time-1.0/24;

        if abs(Return_Time-Current_Time)>0.00001
                Car_Set(i).Route
              fprintf('����ʱ���쳣');
        end
        if abs(Wait_Cost-Car_Set(i).Wait_Cost)>0.00001
                   Car_Set(i).Route
                 fprintf('�ȴ��ɱ��쳣');
        end
         if abs(Distance_cost*Car_Set(i).Per_kil_Cost-Car_Set(i).Transport_Cost)>0.0001
                   Car_Set(i).Route
                 fprintf('����ɱ��쳣');
         end
    end

end

