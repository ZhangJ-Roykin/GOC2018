classdef Car2
    properties
        Route=[]; %�ó��������ڵ�ļ�¼����
        Car_model;%�ó�������
        Save_W=0;
        Ture_Route=[]; 
        Save_V=0;
        Departure_Time;%�ó�����ʱ��
        Return_Time;%�ó������ͻ�����ʱ��
        Total_Distance;%�ó���ʻ���
        Transport_Cost;%����ɱ�
        Electric_Cost;%���ɱ�
        Wait_Cost;%�ȴ��ɱ�
        Fix_Cost;%�̶��ɱ�
        Sum_Cost;%�ܳɱ�
        Electric_Times;%������
        Current_Point;%��ǰ����λ��
        Current_Time;%��ǰʱ��
        Current_Elec;%ʣ�����
        Per_kil_Cost;%�ó�ÿ��������ɱ�
        Volume;%���װ���ݻ�
        Weight;%�˶�����
         Total_Volume;
        Total_Weight;
        Total_Elec;
    end
    
    methods 
        function obj = Car2(Car_model) %�����ʼ��
            obj.Car_model = Car_model;%��������
            obj.Route=[obj.Route 0];%����·��
            obj.Ture_Route=[];
            obj.Departure_Time=8/24;%����ʱ��
            obj.Total_Distance=0;%�����
            obj.Transport_Cost=0;%����ɱ�
            obj.Electric_Cost=0;%���ɱ�
            obj.Wait_Cost=0;%�ȴ��ɱ�
            obj.Electric_Times=0;
            obj.Sum_Cost=1000;
            obj.Current_Point=0;
            obj.Current_Time=obj.Departure_Time;
            if Car_model==1
                obj.Fix_Cost = 200;%�̶��ɱ�
                obj.Current_Elec=100000;%ʣ�����
                obj.Per_kil_Cost=12/1000;
                obj.Volume=12;
                obj.Weight=2.0;
                   obj.Total_Elec=100000;
                   obj.Total_Volume=12;
                obj. Total_Weight=2.0;
            elseif Car_model==2
                obj.Fix_Cost = 300;%�̶��ɱ�
                obj.Current_Elec=120000;%ʣ�����
                obj.Per_kil_Cost=14/1000;
                obj.Volume=16;
                obj.Weight=2.5;
                   obj.Total_Elec=120000;
                   obj.Total_Volume=16;
                obj. Total_Weight=2.5;
            end
        end
    end
    methods 
             function obj = Add(obj,Next_Point,Distance,Wait_time,Delivery_P,Time)  %���³�����Ϣ
                 obj.Route=[obj.Route Next_Point];
                  obj.Ture_Route=[obj.Ture_Route Next_Point];
                 obj.Total_Distance=obj.Total_Distance+Distance;%����̸���
                 obj.Current_Elec=obj.Current_Elec-Distance;%������������
                 obj.Transport_Cost=obj.Transport_Cost+Distance*obj.Per_kil_Cost;  %����ɱ�����
                 obj.Current_Point=Next_Point;%��ǰ�ڵ����
                 obj.Current_Time= obj.Current_Time+Time+Wait_time+0.5/24;   %��ǰʱ�����
                 obj.Wait_Cost= obj.Wait_Cost+Wait_time*24*24;       %�ȴ��ɱ�����
                 
                 obj.Weight=obj.Weight-Delivery_P(1);%ʣ�����ظ���
                 obj.Volume= obj.Volume-Delivery_P(2);%ʣ���������
                 
                 
                 %�ܳɱ�����
                 obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;%�ܳɱ�����
             end
             
            function obj = Add_Elec(obj,Next_Point,Distance,Time)               
                obj.Route=[obj.Route Next_Point];%·������            
                obj.Total_Distance=obj.Total_Distance+Distance;%��̸���
                obj.Transport_Cost=obj.Transport_Cost+Distance*obj.Per_kil_Cost;           
                obj.Current_Point=Next_Point;    
                obj.Current_Time= obj.Current_Time+Time+0.5/24;%��ǰʱ����£���30����
                obj.Electric_Cost =obj.Electric_Cost+50;  %���ɱ�����
                obj.Electric_Times= obj.Electric_Times+1;    %����������
                %���µ���
                if obj.Car_model==1 
                    obj.Current_Elec=100000;
                elseif obj.Car_model==2
                    obj.Current_Elec=120000;
                end
                %�ܳɱ�����
                obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;
            end
            
            
            
            
            function [obj, old_Remain] = Production( old_Remain,obj,Distance,Time,Delivery_P,Distance_min,Remain,k,Max_ID)
                   Flag=1;
                   while(Flag)
                          if length(obj.Route)==1 && Max_ID>0
                               [obj, Next_Point,Flag] =Find_Next_Point( obj,Distance,Time,Delivery_P,Distance_min,Max_ID,k);  
                          else
                              [obj, Next_Point,Flag] =Find_Next_Point( obj,Distance,Time,Delivery_P,Distance_min,Remain,k);  
                          end
                          old_Remain(old_Remain==Next_Point)=[];
                          Remain(Remain==Next_Point)=[];
                    end
             end
            
              function [num] = Num_Business( obj,Delivery_P)
                  Rute=obj.Route;
                  Rute(Rute==0)=[];
                  num=length(find(Delivery_P(Rute+1,2)<4));
                  num(num<0.0001)=0.0001;
             end
%              function [ID_set] = Business_ID( obj,Delivery_P)
%                   Rute=obj.Route;
%                   Rute(Rute==0)=[];
%                   ID= Delivery_P(Rute+1,2)<4;
%                   ID_set=Rute(ID);
%              end
             function [Save] =Saving_Mileage( obj,Delivery_P,Distance)
                 ID_set=Business_ID( obj,Delivery_P);
                 D_old=obj.Total_Distance;
                 D_new=sum(Distance(1,ID_set+1)+Distance(ID_set+1+1));
                 Save=D_new-D_old;
             end
            
            
            
            
            
            
              function obj = Add_Home(obj,Next_Point,D1,T1)                    
                obj.Route=[obj.Route Next_Point];%·������
                obj.Total_Distance=obj.Total_Distance+D1; %            
                obj.Current_Elec=obj.Current_Elec-D1;
                obj.Transport_Cost=obj.Transport_Cost+D1*obj.Per_kil_Cost;
                obj.Current_Point=Next_Point;  
                obj.Current_Time= obj.Current_Time+T1+1.0/24;
                 obj.Wait_Cost= obj.Wait_Cost+1.0*24;       
                if  obj.Car_model==1
                    obj.Current_Elec=100000;
                    obj.Volume=12;
                    obj.Weight=2.0;                 
                elseif obj.Car_model==2
                    obj.Current_Elec=120000;
                    obj.Volume=16;
                    obj.Weight=2.5;
                end
                %�ܳɱ�����
                obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;
            end
    end
end

