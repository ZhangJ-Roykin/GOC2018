function final_fprint( Car_Set,Fie_Name,k)

File_path=['.\Solution\',Fie_Name,'.csv'];

fid=fopen(File_path,'wt','n','utf-8');%д���ļ�·��

    N=length(Car_Set);
    fprintf(fid,'%s','trans_code');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','vehicle_type');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','dist_seq');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','distribute_lea_tm');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','distribute_arr_tm');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','distance');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','trans_cost');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','charge_cost');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','wait_cost');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','fixed_use_cost');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s','total_cost');
    fprintf(fid,'%s',',');
    fprintf(fid,'%s\n','charge_cnt');
   
    for i=1:N
            Car=Car_Set(i);
            trans_code=['DP',sprintf('%04d',i)];
            
            fprintf(fid,'%s',trans_code); 
            fprintf(fid,'%s',',');  
            fprintf(fid,'%d',Car.Car_model);  
            fprintf(fid,'%s',',');  
            for j=1:length(Car.Route)-1
                 if Car.Route(j)>0
                     hh=Car.Route(j)+10000*k;
                 else
                      hh=Car.Route(j);
                 end
                   fprintf(fid,'%d',hh);  
                   fprintf(fid,'%s',';');  
            end
            fprintf(fid,'%d',Car.Route(length(Car.Route)));  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%s',Car.Departure_Time); 
            fprintf(fid,'%s',',');  
            fprintf(fid,'%s',Car.Return_Time);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%d',Car.Total_Distance);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%.2f',Car.Transport_Cost);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%d',Car.Electric_Cost);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%.2f',Car.Wait_Cost);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%d',Car.Fix_Cost);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%.2f',Car. Sum_Cost);  
            fprintf(fid,'%s',',');  
            fprintf(fid,'%d\n',Car. Electric_Times);  
    end  
fclose(fid);
end

