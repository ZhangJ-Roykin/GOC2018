function [ Car_Set ] = Path_Optimization( Distance,Time,Distance_min,Delivery_P,Car_Set_Temp)
    Remain = 1 : (length(Distance)-1-100);%ʣ��û��Ͷ�ݺ����յ��̼�
    Car_Set=[];
    maxmax=max(Distance(1,Remain+1));
    %��ʱ����̼ҽ�������
     [~,Remain]=sort(1.1*(Delivery_P(Remain+1,8)'-Time(1,Remain+1))-0.2*Distance(1,Remain+1)./maxmax);

      for i=1:length(Car_Set_Temp)
         Route=Car_Set_Temp(i).Route;
         Route(Route==0)=[];
         Route(Delivery_P(Route+1,2)==4)=[];       
        if length(Route)>1 
            ID=Route(1);
            Remain(Remain==ID)=[];
            sub_car =new_car(Car(1),Distance,Time,Delivery_P,ID);
            Car_Set=[Car_Set sub_car];
            Last_Point(length(Car_Set))=ID;
        end
      end

       index=Delivery_P(Remain+1,5)>=2.0 |  Delivery_P(Remain+1,6)>=12;
       best=Remain(index);
       Remain(index)=[];
       Remain=[best,Remain];

       while ~isempty(Remain)     
           length(Remain);
            ID=Remain(1);    
            Remain(1)=[];
             index= [Car_Set.Current_Time]+Time([Car_Set.Current_Point]+1,ID+1)'<=Delivery_P(ID+1,8)  &  [Car_Set.Weight]-Delivery_P(ID+1,5)>=0 &   [Car_Set.Volume]-Delivery_P(ID+1,6)>=0;
             if all(index==0) 
                 sub_car =new_car(Car(1),Distance,Time,Delivery_P,ID);
                 Car_Set=[Car_Set sub_car];
                 Last_Point(length(Car_Set))=ID;
             else
                 Cand_V=1:length(Car_Set);
                %������ʱ��Լ���ĳ�����ѡ����                  
                 Cand_V=Cand_V(index);
                 %�ٶ��������Լ��
                 [Cost_Add,Flag]=Cost_Calculation(Car_Set,Cand_V,ID,Delivery_P,Distance,Distance_min,Time);                     
                if ~all(Cost_Add==99999999)           
                    [~,index]=min(Cost_Add);
                    Car_ID=Cand_V(index);
                    if Flag(index)==-1
                        %����Ҫ���               
                        Car_Set(Car_ID) = Add(Car_Set(Car_ID),ID,Distance,Delivery_P,Time);          
                        Last_Point(Car_ID)=ID;
                    else 
                        Current_Point=Car_Set(Car_ID). Current_Point;
                        Car_Set(Car_ID) = Add_Elec( Car_Set(Car_ID),Flag(index),Distance(Current_Point+1,Flag(index)+1),Time(Current_Point+1,Flag(index)+1));   
                        Car_Set(Car_ID) = Add(Car_Set(Car_ID),ID,Distance,Delivery_P,Time);       
                        Last_Point(length(Car_Set))=ID;
                    end
                    %����ID���̼Ҽ��뵽����Car_ID��
                else
                     sub_car =new_car(Car(1),Distance,Time,Delivery_P,ID);
                     Car_Set=[Car_Set sub_car];
                     Last_Point(length(Car_Set))=ID;
                end
             end
 
       end
       
       for i=1:length(Car_Set)
           Car_Set(i)=End(Car_Set(i),Distance,Time);
       end
end


function [Cost_Add,Flag]=Cost_Calculation(Car_Set,Cand_V,ID,Delivery_P,Distance,Distance_min,Time)
            for i=1:length(Cand_V)           
                
                if Delivery_P(ID+1,2)==2
                    W= [Car_Set(Cand_V(i)).Weight]-Delivery_P(ID+1,5)';
                    V=[Car_Set(Cand_V(i)).Volume]-Delivery_P(ID+1,6)';
                elseif Delivery_P(ID+1,2)==3
                    TRoute= Car_Set(Cand_V(i)).Route;
                    TRoute=TRoute(Delivery_P(TRoute+1,2)==2);
                    TWeight1=sum(Delivery_P(TRoute+1,5));
                    TVolume1=sum(Delivery_P(TRoute+1,6));
                    WW=Delivery_P(ID+1,5)-TWeight1+Car_Set(Cand_V(i)).Save_W;
                    WW(WW<0)=0;
                    VV=Delivery_P(ID+1,6)-TVolume1+Car_Set(Cand_V(i)).Save_V;
                    VV(VV<0)=0;
                    W= Car_Set(Cand_V(i)).Weight-WW;
                    V=Car_Set(Cand_V(i)).Volume-VV;
                end


                 if W>=0 && V>=0 && ([Car_Set(Cand_V(i)).Current_Elec]-Distance_min(ID)-Distance([Car_Set(Cand_V(i)).Current_Point]+1,ID+1)')>=0
                     D1=Distance([Car_Set(Cand_V(i)).Current_Point]+1,ID+1);
                     D_Home=Distance([Car_Set(Cand_V(i)).Current_Point]+1,1);
                     D2=Distance(ID+1,1);
                     Cost_D=(D1-0.5*D_Home).*[Car_Set(Cand_V(i)).Per_kil_Cost]';
                     
                     Cost_T=Delivery_P(ID+1,7)-(Time([Car_Set(Cand_V(i)).Current_Point]+1,ID+1)+[Car_Set(Cand_V(i)).Current_Time]');
                     Cost_T(Cost_T<0)=0;
                     
                     Cost_Add(i)=Cost_T*24*24+0.9*Cost_D;
                     if Car_Set(Cand_V(i)).Car_model==2
                         Cost_Add(i)=Cost_T*24*24+0.8*Cost_D;
                     end
                     Flag(i)=-1;
                 elseif W>=0 && V>=0 && ([Car_Set(Cand_V(i)).Current_Elec]-Distance_min(ID)-Distance([Car_Set(Cand_V(i)).Current_Point]+1,ID+1)')<0  
                        %��ȥ�ҳ��׮���
                         % �ȼ�����ȥ�ĳ��׮
                         cand=(length(Distance)-99):length(Distance);              
                         indexs=(Car_Set(Cand_V(i)).Current_Elec-Distance(Car_Set(Cand_V(i)).Current_Point+1,end-99:end)>=0);
                         Can_Ele=cand(indexs);
                         DD=Distance(Car_Set(Cand_V(i)).Current_Point+1,Can_Ele)+Distance(Can_Ele,ID+1)';
                         [~,indexs]=min(DD);    
                         Next_Point=Can_Ele(indexs)-1;              
                         if (Car_Set(Cand_V(i)).Current_Time+Time(Car_Set(Cand_V(i)).Current_Point+1,Next_Point+1)+Time(Next_Point+1,ID+1)  +0.5/24)<=Delivery_P(ID+1,8)
                             Cost_Add(i)=Car_Set(Cand_V(i)).Per_kil_Cost*(Distance(Car_Set(Cand_V(i)).Current_Point+1,Next_Point+1)+Distance(Next_Point+1,ID+1));
                              Cost_Add(i)=Car_Set(Cand_V(i)).Per_kil_Cost*(Distance(Car_Set(Cand_V(i)).Current_Point+1,ID+1))+50;
                              Flag(i)=Next_Point;
                         else
                               Cost_Add(i)=99999999;
                               Flag(i)=-1;
                         end   
                 else        
                       Flag(i)=-1;
                       Cost_Add(i)=99999999;
                 end
            end
end
