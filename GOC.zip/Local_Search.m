function  [Best_Car_Set,Best_cost] = Local_Search( Car_Set,Distance,Time,Distance_min,Delivery_P)
        Remain = 1 : (length(Distance)-1-100);%ȫ��Ͷ�ݺ����յ��̼�
        Best_Car_Set=Car_Set;  
        Best_cost=sum([Car_Set.Sum_Cost]);
        Business_Vehicle=ones((length(Distance)-1-100),6);
        [Business_Vehicle]=Vehicle_Positioning(Car_Set,Delivery_P,Business_Vehicle);
        gen=0;
        Flag=0;
        Current_time=0;
        while 1<298
           if  gen==5000
               %��¼��ǰʱ��
               Current_time=roundn(toc,-1);
                 gen=0;
                    if  Current_time>300
                        break;
                    end
           end
           
            ID=randperm(length(Remain),1);
            ID=Remain(ID);
            gen=gen+1;
            Field_Size=5;
             Penalty=20;
           %�¶ȸ��¹�ʽ
            Temperature=200-200*((Current_time/300).^0.3);
            %������õĽ�
          if Flag==1 
                Current_cost=sum([Car_Set.Sum_Cost]);
               if Current_cost<Best_cost
                     Best_cost=Current_cost
                     Best_Car_Set=Car_Set;
               end
          end
          %�����ѡһ�ֲ���
           Order = randperm(4,1);
          %�ֲ���������
           switch Order
                case  1
                    %ǰ�������
                                    [Car_Set,Business_Vehicle,Flag]=insert_Front(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,Business_Vehicle(ID,1),ID,Remain,Business_Vehicle);
                case  2            
                    %2-opt����
                                    [Car_Set,Business_Vehicle,Flag]=opt2(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,Business_Vehicle(ID,1),ID,Remain,Business_Vehicle);
                case  3       
                    %��������
                                    [Car_Set,Business_Vehicle,Flag]=exhchange(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,Business_Vehicle(ID,1),ID,Remain,Business_Vehicle);         
                case  4        
                    %��������
                                    [Car_Set,Business_Vehicle,Flag]=insert_After(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,Business_Vehicle(ID,1),ID,Remain,Business_Vehicle);
           end

        end
end


function [Car_Set,Business_Vehicle, Flag]=exhchange(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,car_ID,ID,Remain,Business_Vehicle,fitness)    
                Flag=0;
               Route=Car_Set(car_ID).Route;
               Route_N=Car_Set(car_ID).Ture_Route;

                Index=find(Route_N==ID);
                if Index==length(Route_N)
                    Next_point=0;
                    Dead_Time=1.0;
                else
                    Next_point=Route_N(Index+1);
                     Dead_Time=Delivery_P(Next_point+1,8);
                end
                Index=find(Route==ID);
                Time_Point=Car_Set(car_ID).Time_Point;
                %��¼��ID���̼����ڳ����ĳ���ʱ��
                Departure_Time=Time_Point(Index-1);
                %������̼�ǰ�����������ģ���ó���ʱ��Ϊ8:00
                if Index==2
                    %�������ǽ�һ���ʱ���һ����0-1֮�䣬����8���ʱ���0.33333
                    Departure_Time=0.33333333;
                end
                
                Candidate_B=Remain;
            %��һЩ��������Լ���ĺ�ѡ�̼���ǰ�޳�������ʡȥ����ļ��㿪��
           if  ~isempty(Candidate_B)  
               Wait_Time=Departure_Time+Time(Route(Index-1)+1,Candidate_B+1)';
               Wait_time=Delivery_P(Candidate_B+1,7)-Wait_Time;
               Wait_time(Wait_time<0)=0;
               T1=Time(Route(Index-1)+1,Candidate_B+1)'+Time(Candidate_B+1,Next_point+1)+0.5/24+Wait_time;
               index=Departure_Time+T1<Dead_Time+0.000001;
               Candidate_B=Candidate_B(index);
               
               T2=Business_Vehicle(Candidate_B,4)+Time(Business_Vehicle(Candidate_B,2)+1,ID+1)+Time(ID+1,Business_Vehicle(Candidate_B,3)+1)'+0.5/24;
               index=  ( T2<Delivery_P(Business_Vehicle(Candidate_B,3)+1,8)+0.000001);
               Candidate_B=Candidate_B(index);
               
               index= (Departure_Time+Time(Route(Index-1)+1,Candidate_B+1)'<Delivery_P(Candidate_B+1,8)+0.00001);
               Candidate_B=Candidate_B(index);
               index=  (Business_Vehicle(Candidate_B,4)+Time(Business_Vehicle(Candidate_B,2)+1,ID+1)<Delivery_P(ID+1,8)+0.000001);
               Candidate_B=Candidate_B(index);
 
           end
               Candidate_B(Candidate_B==ID)=[];
                %���������Щ�ܽ������̼ң������������ɹ����ܽ��Ͷ��ٳɱ�������ֻ�Ǵ�ż���һ�£���Ϊ��ȷ������Ҫ�ϴ�ļ�����
              if  ~isempty(Candidate_B)  
                    D_O=(Distance(Route(Index-1)+1,ID+1)'+Distance(ID+1,Business_Vehicle(ID,3)+1)')   +(diag(Distance(Business_Vehicle(Candidate_B,2)+1,Candidate_B+1))+ diag(Distance(Candidate_B+1,Business_Vehicle(Candidate_B,3)+1)));                    
                    D_N=(Distance(Route(Index-1)+1,Candidate_B+1)'+ Distance(Candidate_B+1,Business_Vehicle(ID,3)+1))  +   (Distance(Business_Vehicle(Candidate_B,2)+1,ID+1)+Distance(ID+1,Business_Vehicle(Candidate_B,3)+1)');
                    Wait_Cost=(Business_Vehicle(ID,6)+Business_Vehicle(Candidate_B,6)).*576;  
                    %ȥ����Щ������ɱ����ӵĺ�ѡ�̼�
                    indexs=(D_N-D_O)*0.012-0.*Wait_Cost<Penalty+Temperature;  
                    Candidate_B=Candidate_B(indexs);    
                    D_O=D_O(indexs);
                    D_N=D_N(indexs);
                    %�Գɱ���������ȡǰField_Size���̼���Ϊ���պ�ѡ�̼�
                     indexs=D_N-D_O;
%                     [~,IN]=sort(indexs);
%                     Candidate_B=Candidate_B(IN);
%                     L=min(Field_Size,length(Candidate_B));
%                     Candidate_B=Candidate_B(1:L);
              end
               L=min(Field_Size,length(Candidate_B));
              %��Щ��ѡ�̼����ڵĳ���ID
%                 car_ID2=Business_Vehicle(Candidate_B,1);
                %����Щ�̼����ε��̼�ID���н���ǰ��
                for i=1:L
                      [~,IN]=min(indexs);
                   ID2=Candidate_B(IN);
                  car_ID2=Business_Vehicle(ID2,1);
                   Candidate_B(IN)=[];
                   indexs(IN)=[];
                    
                    
                    
%                      ID2=Candidate_B(i);
                     %����������̼���ͬһ����
                    if car_ID2==car_ID
                        Route=Car_Set(car_ID).Ture_Route;
                        %���������̼ҽ��н���
                        Index1= Route==ID;
                        Index2= Route==ID2;
                        Route(Index1)=ID2;
                        Route(Index2)=ID;
                       %���㽻����ĳɱ�
                         [Infor,Route,Ture_Route,FLAG,Sum_Cost]=Produce_carS(Route,Distance,Time,Distance_min,Delivery_P);
                       %����������Ϸ�����FLAGΪ0����ֱ�ӽ�����һ��ѭ��
                         if FLAG==0
                                 continue;
                         end
                         % ReductionΪ�ɱ�������
                          Reduction=Sum_Cost-Car_Set(car_ID).Sum_Cost;
                          % ���ﻹ������ģ���˻���ԣ���һ�������Ͻ��ܲ�Ľ���
                          if (Reduction<0 | rand()<exp(-Reduction/Temperature)) 
                                    Car_Set(car_ID)= Assignment(Car_Set(car_ID),Infor,Route,Ture_Route);
                                    [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,[car_ID car_ID2],Delivery_P);
                                    Flag=1;   
                                  break;
                         end
                    else
                        %    ����������̼��ٲ�ͬ������
                          Route1=Car_Set(car_ID).Ture_Route;
                          Route2=Car_Set(car_ID2).Ture_Route;
                          Index1= Route1==ID;
                          Index2= Route2==ID2;
                            
                          Route1(Index1)=ID2;
                          Route2(Index2)=ID;
                             [Infor2,Route2,Ture_Route2,FLAG,Sum_Cost2]=Produce_carS(Route2,Distance,Time,Distance_min,Delivery_P);
                             if FLAG==0
                                 continue;
                             end
                             [Infor1,Route1,Ture_Route1,FLAG,Sum_Cost1]=Produce_carS(Route1,Distance,Time,Distance_min,Delivery_P);
                             if FLAG==0
                                 continue;
                             end
                             Reduction=Sum_Cost1+Sum_Cost2-sum([Car_Set([car_ID car_ID2]).Sum_Cost]);
                             if (Reduction<0 |  rand()<exp(-Reduction/Temperature))  
                                    Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor1,Route1,Ture_Route1);
                                    Car_Set(car_ID2)=Assignment( Car_Set(car_ID2),Infor2,Route2,Ture_Route2);
                                    [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,[car_ID car_ID2],Delivery_P);
                                    Flag=1;    
                                     break;
                             end
                    end
                end
                
end



function [Car_Set,Business_Vehicle,Flag]=opt2(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,car_ID,ID,Remain,Business_Vehicle,fitness)
  
                Flag=0;
               Route=Car_Set(car_ID).Route;
                Route_N=Car_Set(car_ID).Ture_Route;
                Index=find(Route_N==ID);

                if Index==1
                    After_point=0;
                else
                     After_point=Route_N(Index-1);
                end
                Index=find(Route==ID);
                Time_Point=Car_Set(car_ID).Time_Point;
                Departure_Time=Time_Point(Index-1);
                if Index==2
                    Departure_Time=0.33333333;
                end

                Candidate_B=Remain;
                if    Business_Vehicle(ID,7)==1
                     Candidate_B(Business_Vehicle(Candidate_B,7)==1)=[];
                end

                if  ~isempty(Candidate_B)  
                       T2=Time(Business_Vehicle(Candidate_B,2)+1,ID+1);
                      index=(Business_Vehicle(Candidate_B,4)+T2<Delivery_P(ID+1,8)+0.000001);
                      Candidate_B=Candidate_B(index);
                      if After_point>0
                          T1=Time(After_point+1,Candidate_B+1)';
                          index=Departure_Time+T1<0.000001+Delivery_P(Candidate_B+1,8);
                          Candidate_B=Candidate_B(index);
                      end
                end
                
                
                 Candidate_B(Candidate_B==ID)=[];
                 if  ~isempty(Candidate_B)  
                    D_O=Distance(After_point+1,ID+1)'+diag(Distance(Business_Vehicle(Candidate_B,2)+1,Candidate_B+1));
                    D_N=Distance(After_point+1,Candidate_B+1)'+Distance(Business_Vehicle(Candidate_B,2)+1,ID+1);
                   Wait_Cost=(Business_Vehicle(ID,6)+Business_Vehicle(Candidate_B,6)).*576;  
                    indexs=(D_N-D_O)*0.012-0.*Wait_Cost<Penalty+Temperature;  
                    Candidate_B=Candidate_B(indexs);    
                    D_O=D_O(indexs);
                    D_N=D_N(indexs);
                    indexs=D_N-D_O;

%                     [~,IN]=sort(indexs);
%                     Candidate_B=Candidate_B(IN);        
%                     L=min(Field_Size,length(Candidate_B));
%                     Candidate_B=Candidate_B(1:L);
                    
                 end
                 L=min(Field_Size,length(Candidate_B));
                %����Щ�̼����β��뵽ID�̼�֮ǰ
%                 car_ID2=Business_Vehicle(Candidate_B,1);

                for i=1:L
                   [~,IN]=min(indexs);
                   ID2=Candidate_B(IN);
                  car_ID2=Business_Vehicle(ID2,1);
                   Candidate_B(IN)=[];
                   indexs(IN)=[];
                  
%                     ID2=Candidate_B(i);
                    if car_ID2==car_ID
                        %���������̼ҶԵ�
                        Route=Car_Set(car_ID).Ture_Route;
                        Index1= find(Route==ID);
                        Index2= find(Route==ID2);
                        if Index1<Index2
                            Temp=Route(Index2:-1:Index1);
                            Route(Index1:Index2)=Temp;
                        else
                            Temp=Route(Index1:-1:Index2);
                            Route(Index2:Index1)=Temp;
                        end
                        
                        %����һ���³�
                        [Infor,Route,Ture_Route,FLAG,Sum_Cost]=Produce_carS(Route,Distance,Time,Distance_min,Delivery_P);
                        if FLAG==0
                            continue;
                        end
                        Reduction=Sum_Cost-Car_Set(car_ID).Sum_Cost;
                        
                        if (Reduction<0 |  rand()<exp(-Reduction/Temperature))
                            Car_Set(car_ID)=Assignment( Car_Set(car_ID),Infor,Route,Ture_Route);
                            [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,car_ID,Delivery_P);
                            Flag=1;
                        end
                    else
                        %    ��Ҫ������̼�������������
                        
                        Route1=Car_Set(car_ID).Ture_Route;
                        Route2=Car_Set(car_ID2).Ture_Route;
                        Index1= find(Route1==ID);
                        Index2= find(Route2==ID2);
                        
                        Route11=Route1;
                        Route22=Route2;
                        
                        Route1 =[Route11(1:Index1-1) Route22(Index2:end)];
                        
                        Route2=[Route22(1:Index2-1) Route11(Index1:end)];
                        [Infor2,Route2,Ture_Route2,FLAG,Sum_Cost2]=Produce_carS(Route2,Distance,Time,Distance_min,Delivery_P);
                        if FLAG==0
                            continue;
                        end
                        [Infor1,Route1,Ture_Route1,FLAG,Sum_Cost1]=Produce_carS(Route1,Distance,Time,Distance_min,Delivery_P);
                        if FLAG==0
                            continue;
                        end
                        Reduction=Sum_Cost2+Sum_Cost1- sum([Car_Set([car_ID car_ID2]).Sum_Cost]);
                        if (Reduction<0 |  rand()<exp(-Reduction/Temperature))
                            Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor1,Route1,Ture_Route1);
                            Car_Set(car_ID2)=Assignment(Car_Set(car_ID2),Infor2,Route2,Ture_Route2);
                            [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,[car_ID car_ID2],Delivery_P);
                            Flag=1;
                            break;
                        end
                    end
                end
end






function [Car_Set,Business_Vehicle,Flag]=insert_Front(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,car_ID,ID,Remain,Business_Vehicle,fitness)         
                Flag=0;
                Route=Car_Set(car_ID).Route;
                Index=find(Route==ID);
                Time_Point=Car_Set(car_ID).Time_Point;
                Departure_Time=Time_Point(Index-1);
                if Index==2
                    Departure_Time=8/24;
                end
                Dead_Time=Delivery_P(ID+1,8);
                Candidate_B=Remain;
               if Dead_Time-Departure_Time<0.5/24
                   Candidate_B=[];
               end
               if  ~isempty(Candidate_B)       
                    Wait_Time=Departure_Time+Time(Route(Index-1)+1,Candidate_B+1)'; 
                    Wait_time=Delivery_P(Candidate_B+1,7)-Wait_Time;             
                    Wait_time(Wait_time<0)=0;  
                    T1=Time(Route(Index-1)+1,Candidate_B+1)'+Time(Candidate_B+1,ID+1)+0.5/24+Wait_time;
                    index=Departure_Time+T1<Dead_Time+0.00000001;
                    Candidate_B=Candidate_B(index);

                   index=(Departure_Time+Time(Route(Index-1)+1,Candidate_B+1)'<Delivery_P(Candidate_B+1,8)+0.000001);
                   Candidate_B=Candidate_B(index);

               end
               Candidate_B(Candidate_B==ID)=[];

                 if  ~isempty(Candidate_B)  

                     D_O=Distance(Route(Index-1)+1,ID+1)'+(diag(Distance(Business_Vehicle(Candidate_B,2)+1,Candidate_B+1)));
                     D_N=((Distance(Route(Index-1)+1,Candidate_B+1)'+Distance(Candidate_B+1,ID+1))) +(diag(Distance(Business_Vehicle(Candidate_B,2)+1,Business_Vehicle(Candidate_B,3)+1)));
                     Wait_Cost=(Business_Vehicle(ID,6)+Business_Vehicle(Candidate_B,6)).*576;  
                    indexs=(D_N-D_O)*0.012-0.*Wait_Cost<Penalty+Temperature;  
                    Candidate_B=Candidate_B(indexs);    
                    D_O=D_O(indexs);
                    D_N=D_N(indexs);
                    
                     indexs=D_N-D_O;
%                      [~,IN]=sort(indexs);
%                      Candidate_B=Candidate_B(IN);
%                      L=min(Field_Size,length(Candidate_B));
%                      Candidate_B=Candidate_B(1:L);
                end


%                 car_ID2=Business_Vehicle(Candidate_B,1); 
        L=min(Field_Size,length(Candidate_B));
                for i=1:L
                   [~,IN]=min(indexs);
                   ID2=Candidate_B(IN);
                  car_ID2=Business_Vehicle(ID2,1);
                   Candidate_B(IN)=[];
                   indexs(IN)=[];
                    if car_ID2==car_ID

                        Route=Car_Set(car_ID).Ture_Route;
                        Route(Route==ID2)=[];
                         Index1=find(Route==ID);
                         
                        Route=[Route(1:Index1-1) ID2 Route(Index1:end)];

                         [Infor,Route,Ture_Route,FLAG,Sum_Cost]=Produce_carS(Route,Distance,Time,Distance_min,Delivery_P);
                          if FLAG==0
                                 continue;
                          end

                         Reduction=Sum_Cost-Car_Set(car_ID).Sum_Cost;
                         if (Reduction<0 |  rand()<exp(-Reduction/Temperature)) 

                                 Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor,Route,Ture_Route);
                                 [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,car_ID,Delivery_P);     
                                 Flag=1; 
                                 break;
                         end
                    else
                        Route1=Car_Set(car_ID).Ture_Route;
                        Route2=Car_Set(car_ID2).Ture_Route;
                        Index1=find(Route1==ID);
                        
                        Route1=[Route1(1:Index1-1) ID2 Route1(Index1:end)];
                        Route2( Route2==ID2)=[];
                        
                        Cars2=0;
                        Sum_Cost2=0;
                         if ~isempty(Route2)
                             [Infor2,Route2,Ture_Route2,FLAG,Sum_Cost2]=Produce_carS(Route2,Distance,Time,Distance_min,Delivery_P);
                             if FLAG==0
                                 continue;
                             end
                             Cars2=1;
                         end

                         [Infor1,Route1,Ture_Route1,FLAG,Sum_Cost1]=Produce_carS(Route1,Distance,Time,Distance_min,Delivery_P);
                         if FLAG==0
                             continue;
                         end
      
                        Reduction=Sum_Cost1+Sum_Cost2- sum([Car_Set([car_ID car_ID2]).Sum_Cost]);
                         if ( Reduction<0 | rand()<exp(-Reduction/Temperature))
                            if Cars2==1
                                Car_Set(car_ID)=Assignment( Car_Set(car_ID),Infor1,Route1,Ture_Route1);
                                Car_Set(car_ID2)=Assignment(Car_Set(car_ID2),Infor2,Route2,Ture_Route2);
                                [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,[car_ID car_ID2],Delivery_P);                          
                                Flag=1; %����ɹ�
                                break;
                            else
                                  Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor1,Route1,Ture_Route1);
                                if Cars2==0
                                    Car_Set(car_ID2)=[];
                                else
                                    Car_Set(car_ID2)= Assignment(Car_Set(car_ID2),Infor2,Route2,Ture_Route2);
                                end
                                [Business_Vehicle]=Vehicle_Positioning(Car_Set,Delivery_P,Business_Vehicle);
                                Flag=1; %����ɹ�
                                break;
                            end
                        end
                        
                    end
                end
end


function [Car_Set,Business_Vehicle, Flag]=insert_After(Penalty,Temperature,Field_Size,Car_Set,Distance,Time,Distance_min,Delivery_P,car_ID,ID,Remain,Business_Vehicle)           
                Flag=0;
                Route=Car_Set(car_ID).Route;
                Route_N=Car_Set(car_ID).Ture_Route;
                Index=find(Route_N==ID);

                if Index==length(Route_N)
                    Next_point=0;
                    Dead_Time=1.0;
                else
                    Next_point=Route_N(Index+1);
                    Dead_Time=Delivery_P(Next_point+1,8);
                end
                Index= Route==ID;
                Time_Point=Car_Set(car_ID).Time_Point;
                Departure_Time=Time_Point(Index);
                Candidate_B=Remain;
                   if  ~isempty(Candidate_B)  
                         Wait_Time=Departure_Time+Time(ID+1,Candidate_B+1)'; 
                         Wait_time=Delivery_P(Candidate_B+1,7)-Wait_Time;             
                         Wait_time(Wait_time<0)=0;  
                         T1=Time(ID+1,Candidate_B+1)'+Time(Candidate_B+1,Next_point+1)+0.5/24+Wait_time;
                          index=Departure_Time+T1<Dead_Time+0.00001;
                         Candidate_B=Candidate_B(index);
                         index=Departure_Time+Time(ID+1,Candidate_B+1)'<Delivery_P(Candidate_B+1,8)+0.00001;
                         Candidate_B=Candidate_B(index);                    
                   end
                Candidate_B(Candidate_B==ID)=[];
               if  ~isempty(Candidate_B)  
                   D_O=Distance(ID+1,Business_Vehicle(ID,3)+1)+ (diag(Distance(Business_Vehicle(Candidate_B,2)+1,Candidate_B+1))+  diag(Distance(Candidate_B+1,Business_Vehicle(Candidate_B,3)+1)));
                   D_N=(Distance(ID+1,Candidate_B+1)'+Distance(Candidate_B+1,Business_Vehicle(ID,3)+1))+diag(Distance(Business_Vehicle(Candidate_B,2)+1,Business_Vehicle(Candidate_B,3)+1));
                     Wait_Cost=(Business_Vehicle(ID,6)+Business_Vehicle(Candidate_B,6)).*576;  
                    indexs=(D_N-D_O)*0.012-0.*Wait_Cost<Penalty+Temperature;  
                    Candidate_B=Candidate_B(indexs);    
                    D_O=D_O(indexs);
                    D_N=D_N(indexs);
                   indexs=D_N-D_O;
%                    [~,IN]=sort(indexs);
%                    Candidate_B=Candidate_B(IN);
%                    L=min(Field_Size,length(Candidate_B));
%                    Candidate_B=Candidate_B(1:L);
               end
                
           
                L=min(Field_Size,length(Candidate_B));

                for i=1:L
                     [~,IN]=min(indexs);
                   ID2=Candidate_B(IN);
                  car_ID2=Business_Vehicle(ID2,1);
                   Candidate_B(IN)=[];
                   indexs(IN)=[];
                   
                    if car_ID2==car_ID

                        Route=Car_Set(car_ID).Ture_Route;
                        Route(Route==ID2)=[];
                        Index1= find(Route==ID);
                          Route=[Route(1:Index1) ID2 Route(Index1+1:end)];
                            [Infor,Route,Ture_Route,FLAG,Sum_Cost]=Produce_carS(Route,Distance,Time,Distance_min,Delivery_P); 
                             if FLAG==0
                                    continue;
                             end
                         Reduction=Sum_Cost-Car_Set(car_ID).Sum_Cost;
                          if (Reduction<0 | rand()<exp(-Reduction/Temperature)) 
                                  Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor,Route,Ture_Route);
                                 [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,[car_ID car_ID2],Delivery_P);
                                 Flag=1;
                                  break;
                         end
                    else

                          Route1=Car_Set(car_ID).Ture_Route;
                          Route2=Car_Set(car_ID2).Ture_Route;
                          Index1= find(Route1==ID);
                          Route1=[Route1(1:Index1) ID2 Route1(Index1+1:end)];    
                          Route2(Route2==ID2)=[];           
                             Cars2=0;
                             Sum_Cost2=0;
                             [Infor1,Route1,Ture_Route1,FLAG,Sum_Cost1]=Produce_carS(Route1,Distance,Time,Distance_min,Delivery_P);
                             if FLAG==0
                                 continue;
                             end
                            if ~isempty(Route2)
                                [Infor2,Route2,Ture_Route2,FLAG,Sum_Cost2]=Produce_carS(Route2,Distance,Time,Distance_min,Delivery_P);
                                if FLAG==0
                                    continue;
                                end
                                Cars2=1;
                            end
                               Reduction=Sum_Cost1+Sum_Cost2- sum([Car_Set([car_ID car_ID2]).Sum_Cost]);
                              if ( Reduction<0 | rand()<exp(-Reduction/Temperature)) 
                                if  Cars2==1
                                    Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor1,Route1,Ture_Route1);
                                    Car_Set(car_ID2)=Assignment(Car_Set(car_ID2),Infor2,Route2,Ture_Route2);
                                    [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,[car_ID car_ID2],Delivery_P);
                                    Flag=1;
                                      break;
                                else
                                        Car_Set(car_ID)=Assignment(Car_Set(car_ID),Infor1,Route1,Ture_Route1);
                                     if Cars2==0
                                         Car_Set(car_ID2)=[];
                                     else
                                          Car_Set(car_ID2)=Assignment(Car_Set(car_ID2),Infor2,Route2,Ture_Route2);
                                     end
                                    Flag=1;
                                    [Business_Vehicle]=Vehicle_Positioning(Car_Set,Delivery_P,Business_Vehicle);
                                    break;
                                 end
                              end
                    end
                end
end


function [Business_Vehicle]=Vehicle_Positioning(Car_Set,Delivery_P,Business_Vehicle)
         for i=1:length(Car_Set)
             ID_set= Car_Set(i).Ture_Route;
             Business_Vehicle(ID_set,1)=i; 
             Time_Point= Car_Set(i).Time_Point;
             Route=Car_Set(i).Route;
             %�������ĵ���ʱ��
             Wait_Time=Car_Set(i).Wait_Time;
             Time_Point(1)=0.333333;
             Time_Point(end)=1;
             index= find(Delivery_P(Route+1,2)==2 | Delivery_P(Route+1,2)==3);
             qian=index-1;
             qian(Delivery_P(Route(qian)+1,2)==4)=qian(Delivery_P(Route(qian)+1,2)==4)-1;
             hou=index+1;
             hou(Delivery_P(Route(hou)+1,2)==4)=hou(Delivery_P(Route(hou)+1,2)==4)+1;
             Business_Vehicle(ID_set,2)=Route(qian);%ÿ���̼ҵ�ǰ�̽ڵ�
             Business_Vehicle(ID_set,3)=Route(hou);%ÿ���̼ҵĺ�̽ڵ�
             Business_Vehicle(ID_set,4)=Time_Point(qian);%ǰ�̽ڵ����ʱ��
             Business_Vehicle(ID_set,5)=Time_Point(hou);%��̽ڵ����ʱ��
             Business_Vehicle(ID_set,6)=Wait_Time(index);%ÿ���̼ҵĺ�̽ڵ�
             Business_Vehicle(ID_set,7)=1:length(ID_set);%����λ��
         end
end
function [Business_Vehicle]=ReVehicle_Positioning(Business_Vehicle,Car_Set,LENG,Delivery_P)
         for i=1:length(LENG)
             id=LENG(i);
             ID_set=Car_Set(id).Ture_Route;
             Business_Vehicle(ID_set,1)=id;    
             Time_Point= Car_Set(id).Time_Point;
             Route=Car_Set(id).Route;
             %�������ĵ���ʱ��
             index= find(Delivery_P(Route+1,2)==2 | Delivery_P(Route+1,2)==3);
            Time_Point(1)=0.333333;
             Time_Point(end)=1;
             qian=index-1;
             qian(Delivery_P(Route(qian)+1,2)==4)=qian(Delivery_P(Route(qian)+1,2)==4)-1;
             hou=index+1;
             hou(Delivery_P(Route(hou)+1,2)==4)=hou(Delivery_P(Route(hou)+1,2)==4)+1;
             Wait_Time=Car_Set(id).Wait_Time;
             Business_Vehicle(ID_set,2)=Route(qian);%ÿ���̼ҵ�ǰ�̽ڵ�
             Business_Vehicle(ID_set,3)=Route(hou);%ÿ���̼ҵĺ�̽ڵ�
             Business_Vehicle(ID_set,4)=Time_Point(qian);%ǰ�̽ڵ����ʱ��
             Business_Vehicle(ID_set,5)=Time_Point(hou);%��̽ڵ����ʱ��
             Business_Vehicle(ID_set,6)=Wait_Time(index);%ÿ���̼ҵĺ�̽ڵ�
             Business_Vehicle(ID_set,7)=1:length(ID_set);%����λ��
         end
end
