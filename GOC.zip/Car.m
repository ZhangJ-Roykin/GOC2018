classdef Car
    properties
        Route=[]; %�ó��������ڵ�ļ�¼����
        Time_Point=[];
        Wait_Time=[];
        Ture_Route=[]; 
        Save_W;
        Save_V;
        Car_model;%�ó�������
        Departure_Time;%�ó�����ʱ��
        Return_Time;%�ó������ͻ�����ʱ��
        Total_Distance;%�ó���ʻ���
        Transport_Cost;%����ɱ�
        Electric_Cost;%���ɱ�
        Wait_Cost;%�ȴ��ɱ�
        Fix_Cost;%�̶��ɱ�
        Sum_Cost;%�ܳɱ�
        Electric_Times;%������
        Current_Point;%��ǰ����λ��
        Current_Time;%��ǰʱ��
        Current_Elec;%ʣ�����
        Per_kil_Cost;%�ó�ÿ��������ɱ�
        Volume;%���װ���ݻ�
        Weight;%�˶�����
        Total_Volume;
        Total_Weight;
        Total_Elec;
    end
    
    methods 
        function obj = Car(Car_model) %�����ʼ��
            obj.Car_model = Car_model;%��������
            obj.Route=[obj.Route 0];%����·��
            obj.Ture_Route=[];
            obj.Wait_Time=[obj.Wait_Time 0];
            obj.Departure_Time=0.333333333;%����ʱ��
            obj.Time_Point(1)=obj.Departure_Time;
            obj.Total_Distance=0;%�����
            obj.Save_W=0;
            obj.Save_V=0;
            obj.Transport_Cost=0;%����ɱ�
            obj.Electric_Cost=0;%���ɱ�
            obj.Wait_Cost=0;%�ȴ��ɱ�
            obj.Electric_Times=0;
            obj.Sum_Cost=1000;
            obj.Current_Point=0;
            obj.Current_Time=obj.Departure_Time;
            if Car_model==1
                obj.Fix_Cost = 200;%�̶��ɱ�
                obj.Current_Elec=100000;%ʣ�����
                obj.Total_Elec=100000;
                obj.Per_kil_Cost=0.012;
                obj.Volume=12;
                obj.Weight=2.0;
                obj.Total_Volume=12;
                obj. Total_Weight=2.0;
            elseif Car_model==2
                obj.Fix_Cost = 300;%�̶��ɱ�
                obj.Current_Elec=120000;%ʣ�����
                obj.Total_Elec=120000;
                obj.Per_kil_Cost=0.014;
                obj.Volume=16;
                obj.Weight=2.5;
                obj.Total_Volume=16;
                obj. Total_Weight=2.5;
            end
        end
         
    end
    methods 
             function obj = Add(obj,Next_Point,Distance,Delivery_P,Time)  %���³�����Ϣ
                  
                 D=Distance(obj.Current_Point+1,Next_Point+1);
                 T=Time(obj.Current_Point+1,Next_Point+1);                
                 Wait_time=Delivery_P(Next_Point+1,7)-(T+obj.Current_Time);
                 Wait_time(Wait_time<0)=0;               
                 obj.Route=[obj.Route Next_Point];
                 obj.Ture_Route=[obj.Ture_Route Next_Point];
                 obj.Wait_Time=[obj.Wait_Time Wait_time];
                 Delivery=Delivery_P(Next_Point+1,5:6);
                 
                 obj.Total_Distance=obj.Total_Distance+D;%����̸���
                 obj.Current_Elec=obj.Current_Elec-D;%������������
                 obj.Transport_Cost=obj.Transport_Cost+D*obj.Per_kil_Cost;  %����ɱ�����
                 obj.Current_Point=Next_Point;%��ǰ�ڵ����
                 
                 obj.Time_Point(end)=obj.Current_Time;
                 obj.Current_Time= obj.Current_Time+T+Wait_time+0.5/24;   %��ǰʱ�����
                 obj.Time_Point(end+1)=obj.Current_Time;
                  
                 obj.Wait_Cost= obj.Wait_Cost+Wait_time*576;       %�ȴ��ɱ�����   
                  if Delivery_P(Next_Point+1,2)==2
                       obj.Weight=obj.Weight-Delivery(1);%ʣ�����ظ���
                       obj.Volume= obj.Volume-Delivery(2);%ʣ���������
                  else
                            TRoute= obj.Route;
                            TRoute=TRoute(Delivery_P(TRoute+1,2)==2);
                            TWeight1=sum(Delivery_P(TRoute+1,5));
                            TVolume1=sum(Delivery_P(TRoute+1,6));
                            
                             W=Delivery(1)-TWeight1+sum(obj.Save_W);
                             W(W<0)=0;
                             V=Delivery(2)-TVolume1+sum(obj.Save_V);
                             V(V<0)=0;
                             obj.Weight=obj.Weight-W;%ʣ�����ظ���
                             obj.Volume= obj.Volume-V;%ʣ���������

                             obj.Save_W=obj.Save_W+(Delivery(1)-W);
                             obj.Save_V=obj.Save_V+ (Delivery(2)-V);
                  end
                 %�ܳɱ�����
                 obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;%�ܳɱ�����
             end
             
            function obj = Add_Elec(obj,Next_Point,Distance,Time)               
                obj.Route=[obj.Route Next_Point];%·������           
                obj.Wait_Time=[obj.Wait_Time 0];
                obj.Total_Distance=obj.Total_Distance+Distance;%��̸���
                obj.Transport_Cost=obj.Transport_Cost+Distance*obj.Per_kil_Cost;           
                obj.Current_Point=Next_Point;    
                obj.Current_Time= obj.Current_Time+Time+0.5/24;%��ǰʱ����£���30����
                obj.Time_Point(end+1)=obj.Current_Time;
                obj.Electric_Cost =obj.Electric_Cost+50;  %���ɱ�����
                obj.Electric_Times= obj.Electric_Times+1;    %����������
                %���µ���
                if obj.Car_model==1 
                    obj.Current_Elec=100000;
                elseif obj.Car_model==2
                    obj.Current_Elec=120000;
                end
                %�ܳɱ�����
                obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;
            end
            function [sub_car] = new_car(~,Distance,Time,Delivery_P,ID)
                if Delivery_P(ID+1,5)>2.0 || Delivery_P(ID+1,6)>12.0
                    sub_car=Car(2);
                else
                    sub_car=Car(1);
                end
                Wait_time=Delivery_P(ID+1,7)'-(sub_car.Current_Time+Time(1,ID+1));
                Wait_time(Wait_time<0)=0;
                sub_car = Add(sub_car,ID,Distance,Delivery_P,Time);
                %��Ϊ�ǵ�һ�η�������û�еȴ�ʱ��                 
                 sub_car.Departure_Time=sub_car.Departure_Time+Wait_time;
                 sub_car.Wait_Cost=0;%���ȴ��ɱ���Ϊ0
                 sub_car.Sum_Cost=sub_car.Fix_Cost+ sub_car.Transport_Cost+ sub_car.Electric_Cost+sub_car.Wait_Cost;%�ܳɱ�����
            end
            
%               function [sub_car] = new_car2(sub_car,Car_model,Distance,Time,Delivery_P,ID)          
%                 Wait_time=Delivery_P(ID+1,7)-(sub_car.Current_Time+Time(1,ID+1));
%                 Wait_time(Wait_time<0)=0;
%                 sub_car = Add(sub_car,ID,Distance,Delivery_P,Time);
%                 %��Ϊ�ǵ�һ�η�������û�еȴ�ʱ��                 
%                  sub_car.Departure_Time=sub_car.Departure_Time+Wait_time;
%                  sub_car.Wait_Cost=0;%���ȴ��ɱ���Ϊ0
%                  sub_car.Sum_Cost=sub_car.Fix_Cost+ sub_car.Transport_Cost+ sub_car.Electric_Cost+sub_car.Wait_Cost;%�ܳɱ�����
%             end
            
              function [obj] = End(obj,Distance,Time)
                  if  obj.Current_Point~=0
                       if obj.Current_Elec-Distance(obj.Current_Point+1,1)>-0.0001
                          obj=Add_Home(obj,0,Distance(obj.Current_Point+1,1),Time(obj.Current_Point+1,1));
                      else
                           temp= find(obj.Current_Elec-Distance(obj.Current_Point+1,end-99:end)>0);
                           temp_point=length(Distance)-100-1+temp;             
                            [~,kk]=min(Distance(obj.Current_Point+1,temp_point+1)+Distance(temp_point+1,1)');
                            Next_Point=temp_point(kk);
                            D1=Distance(obj.Current_Point+1,Next_Point+1);
                            T1=Time(obj.Current_Point+1,Next_Point+1);
                            obj=Add_Elec(obj,Next_Point,D1,T1);
                            
                            if obj.Current_Point~=0
                                    obj=Add_Home(obj,0,Distance(obj.Current_Point+1,1),Time(obj.Current_Point+1,1));
                            end
             
                      end
                  end
                  obj.Time_Point(end)=obj.Current_Time;
                 obj.Wait_Cost= obj.Wait_Cost-24;  
                 obj.Sum_Cost= obj.Sum_Cost-24;  
              end
            
              
              function [obj] = End_H(obj,Distance,Time)
                  if  obj.Current_Point~=0
                       if obj.Current_Elec-Distance(obj.Current_Point+1,1)>0
                          obj=Add_Home(obj,0,Distance(obj.Current_Point+1,1),Time(obj.Current_Point+1,1));
                      else
                           temp= find(obj.Current_Elec-Distance(obj.Current_Point+1,end-99:end)>0);
                           temp_point=length(Distance)-100-1+temp;             
                            [~,kk]=min(Distance(obj.Current_Point+1,temp_point+1)+Distance(temp_point+1,1)');
                            Next_Point=temp_point(kk);
                            D1=Distance(obj.Current_Point+1,Next_Point+1);
                            T1=Time(obj.Current_Point+1,Next_Point+1);
                            obj=Add_Elec(obj,Next_Point,D1,T1);
                            obj=Add_Home(obj,0,Distance(obj.Current_Point+1,1),Time(obj.Current_Point+1,1));

                      end
                  end
              end


            
            function [obj, old_Remain] = Production( old_Remain,obj,Distance,Time,Delivery_P,Distance_min,Remain,k,Max_ID)
                   Flag=1;
                   while(Flag)
                          if length(obj.Route)==1 && Max_ID>0
                               [obj, Next_Point,Flag] =Find_Next_Point( obj,Distance,Time,Delivery_P,Distance_min,Max_ID,k);  
                          else
                              [obj, Next_Point,Flag] =Find_Next_Point( obj,Distance,Time,Delivery_P,Distance_min,Remain,k);  
                          end
                          old_Remain(old_Remain==Next_Point)=[];
                          Remain(Remain==Next_Point)=[];
                    end
             end

              
               function [obj] = Assignment(obj,Infor,Route,Ture_RouteT)


       %1 ��ǰ��   2 ʣ����� 3ʣ���ݻ� 4ʣ����� 5 ������� 6 ����ʱ�� 7 ��Լ���  
       % Current_Point
       %  8��Լ�ݻ� 9������ 10 ��ǰʱ�� 11��������  12 ����ʻ���
       % Infor=[];
       
                            obj.Route=Route(1,:); %�ó��������ڵ�ļ�¼����
                            obj.Time_Point=Route(2,:);
                            obj.Wait_Time=Route(3,:);
                            obj.Save_W=Infor(7);
                            obj.Save_V=Infor(8);
                            obj.Car_model=Infor(11);%�ó�������
                            obj.Departure_Time=Infor(6);%�ó�����ʱ��
%                             obj.Return_Time;%�ó������ͻ�����ʱ��
                            obj.Total_Distance=Infor(12);%�ó���ʻ���

                            obj.Electric_Cost=Infor(9)*50;%���ɱ�
                            obj.Wait_Cost=sum(Route(3,:))*24*24;%�ȴ��ɱ�
                            obj.Electric_Times=Infor(9);%������
                            obj.Current_Point=Infor(1);%��ǰ����λ��
                            obj.Current_Time=Infor(10);%��ǰʱ��
                            obj.Current_Elec=Infor(4);%ʣ�����
                            obj.Ture_Route=Ture_RouteT;

                            obj.Weight=Infor(2);%�˶�����
                           obj.Volume=Infor(3);%���װ���ݻ�

                            if  obj.Car_model==1
                                 obj.Fix_Cost=200;
                                 obj.Total_Volume=12;
                                 obj.Total_Weight=2.0;
                                 obj.Per_kil_Cost=0.012;
                                 obj.Total_Elec=100000;
                            else
                                obj.Fix_Cost=300;
                                obj.Total_Volume=16;
                                obj.Total_Weight=2.5;
                                obj.Per_kil_Cost=0.014;
                                obj.Total_Elec=100000;
                            end
                             obj.Transport_Cost=obj.Total_Distance* obj.Per_kil_Cost;%����ɱ�
                            
                            obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;

               end
              
               

               
               
                 function [obj] = HU(obj)
                  obj.Return_Time= datestr(obj.Current_Time-1.0/24,'HH:MM');
                 obj.Departure_Time= datestr(obj.Departure_Time,'HH:MM');                
                end
               
               
               
               
               
               
               
            
            
              function obj = Add_Home(obj,Next_Point,D1,T1)        
                obj.Route=[obj.Route Next_Point];%·������
                obj.Wait_Time=[obj.Wait_Time 0];
                obj.Total_Distance=obj.Total_Distance+D1; %            
                obj.Current_Elec=obj.Current_Elec-D1;
                obj.Transport_Cost=obj.Transport_Cost+D1*obj.Per_kil_Cost;
                obj.Current_Point=Next_Point;  
                obj.Current_Time= obj.Current_Time+T1+1.0/24;
                obj.Time_Point(end+1)=obj.Current_Time;
                 obj.Wait_Cost= obj.Wait_Cost+24;       
                if  obj.Car_model==1
                    obj.Current_Elec=100000;
                    obj.Volume=12;
                    obj.Weight=2.0;                 
                elseif obj.Car_model==2
                    obj.Current_Elec=120000;
                    obj.Volume=16;
                    obj.Weight=2.5;
                end
                %�ܳɱ�����
                obj.Sum_Cost=obj.Fix_Cost+ obj.Transport_Cost+ obj.Electric_Cost+obj.Wait_Cost;
            end
    end
end

