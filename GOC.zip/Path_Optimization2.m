function [ Car_Set ] = Path_Optimization2( Distance,Time,Distance_min,Delivery_P)

%       Delivery_P(Delivery_P(:,2)==3,5:6)=0;

    Remain = 1 : (length(Distance)-1-100);%ʣ��û��Ͷ�ݺ����յ��̼�
    Car_Set=[];
    while  ~isempty(Remain)
        %˳��ʣ���̼�������������������̼�
        Max_ID=-1; 
       Sub_car1 = Car2(1);%����С����һ��
        old_Remain=Remain;
       %�ȰѴ����Ʒ�ҳ���
       index=Delivery_P(Remain+1,5)>2.0 |  Delivery_P(Remain+1,6)>12;
       Remain_Temp=Remain(index);
       if isempty(Remain_Temp)
           Remain_Temp=Remain;
       end
       
       
        [Sub_car1,Remain1] = Production( old_Remain,Sub_car1,Distance,Time,Delivery_P,Distance_min,Remain_Temp,2,Max_ID);
        Cost1_Rate=Sub_car1.Sum_Cost/Num_Business( Sub_car1,Delivery_P);
         
        Sub_car2 = Car2(2);%���ô���һ��
        [Sub_car2,Remain] = Production( old_Remain,Sub_car2,Distance,Time,Delivery_P,Distance_min,Remain_Temp,1,Max_ID);

        Cost2_Rate=Sub_car2.Sum_Cost/Num_Business( Sub_car2,Delivery_P);
        % Cost2_Rate=Sub_car2.Sum_Cost/sum(Delivery_P(Business_ID( Sub_car2,Delivery_P)+1,5));
        
        FL=length(find(Delivery_P(Sub_car2.Ture_Route+1,5)>2.0)) +length(find(Delivery_P(Sub_car2.Ture_Route+1,6)>12));
        if FL>0 
            Car_Set=[Car_Set Sub_car2];
        else
            Car_Set=[Car_Set Sub_car1];
            Remain=Remain1;
        end

    end
end

