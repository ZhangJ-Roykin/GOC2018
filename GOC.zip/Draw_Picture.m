function  Draw_Picture(GPS,Route,Remain )

    
  
        %����������·�����Ƴ�����
%         for i=1:length(Route)-1
%              hold on;
%           %   plot([GPS(GPS(:,1)==Route(i),3),GPS(GPS(:,1)==Route(i+1),3)],[GPS(GPS(:,1)==Route(i),4),GPS(GPS(:,1)==Route(i+1),4)],'color','r');hold on; 
%              hold on;
%              draw_arrow([GPS(GPS(:,1)==Route(i),3) GPS(GPS(:,1)==Route(i),4)],[GPS(GPS(:,1)==Route(i+1),3) GPS(GPS(:,1)==Route(i+1),4)],0.03)
%            %  annotation('arrow',[GPS(GPS(:,1)==Route(i),3) GPS(GPS(:,1)==Route(i),4)],[GPS(GPS(:,1)==Route(i+1),3) GPS(GPS(:,1)==Route(i+1),4)]); 
%         end
%         
%         for i=1:length(Route)
%             hold on;
%              plot(GPS(GPS(:,1)==Route(i),3),GPS(GPS(:,1)==Route(i),4),'o','color','m','markersize',10); 
%               
%         end 
     hold on;
     %���׮
     plot(GPS(GPS(:,2)==4,3),GPS(GPS(:,2)==4,4),'o','color','b'); 
     %�̼�λ��
%      hold on;
%       plot(GPS(Remain+1,3),GPS(Remain+1,4),'*','color','k'); 
      
        hold on;
      plot(GPS(GPS(:,2)==2,3),GPS(GPS(:,2)==2,4),'*','color','k'); 
      hold on;
      plot(GPS(GPS(:,2)==3,3),GPS(GPS(:,2)==3,4),'*','color','k'); 
   
   
      %��������
      hold on;
      plot(GPS(GPS(:,2)==1,3),GPS(GPS(:,2)==1,4),'o','markerfacecolor', [ 1, 0, 0 ] );
end
function draw_arrow(startpoint,endpoint,headsize)

    v1 = headsize*(startpoint-endpoint)/2.5; 

    theta = 22.5*pi/180; 

    theta1 = -1*22.5*pi/180; 

    rotMatrix = [cos(theta)  -sin(theta) ; sin(theta)  cos(theta)];

    rotMatrix1 = [cos(theta1)  -sin(theta1) ; sin(theta1)  cos(theta1)];  

    v2 = v1*rotMatrix; 

    v3 = v1*rotMatrix1; 

    x1 = endpoint;

    x2 = x1 + v2; 

    x3 = x1 + v3; 

    hold on; 

    fill([x1(1) x2(1) x3(1)],[x1(2) x2(2) x3(2)],[0 0 0]);% this fills the arrowhead (black) 
   hold on; 
    plot([startpoint(1) endpoint(1)],[startpoint(2) endpoint(2)],'linewidth',1,'color',[0 0 0]);
end
