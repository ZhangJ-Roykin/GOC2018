function [Infor,Route,Ture_Route,Falg,Sum_Cost]=Produce_carS(Remain,Distance,Time,Distance_min,Delivery_P)
         %1 �������� 2 ʣ����� 3ʣ���ݻ� 4ʣ����� 5 ������� 6 
        Infor=[];
        Route(1:3,:)=0;
        Ture_Route=Remain;
        if sum(Delivery_P(Remain+1,5)>2)>0 | sum(Delivery_P(Remain+1,6)>12)>0
           [Infor,Route] =new_car2(Infor,Route,2,Distance,Time,Delivery_P,Remain(1));
        else
            [Infor,Route] =new_car2(Infor,Route,1,Distance,Time,Delivery_P,Remain(1));
        end
         Remain(1)=[];
         Falg=1;
    
    while ~isempty(Remain)     
            ID=Remain(1);    
            Remain(1)=[];
             Current_Time=Infor(10);
             Current_Point=Infor(1);
             T= Delivery_P(ID+1,8)-(Current_Time+Time(Current_Point+1,ID+1)); 
             if T<0
                 Falg=0;
                 break;
             end
            if Delivery_P(ID+1,2)==2
                 W= Infor(2)-Delivery_P(ID+1,5);
                 V=Infor(3)-Delivery_P(ID+1,6);    
            else
                TRoute=Route(1,:);
                TRoute=TRoute(Delivery_P(TRoute+1,2)==2);
                W= Infor(2)-max(Delivery_P(ID+1,5)-sum(Delivery_P(TRoute+1,5))+Infor(7),0);
                V=Infor(3)-max(Delivery_P(ID+1,6)-sum(Delivery_P(TRoute+1,6))+Infor(8),0);
            end

             if   W>=0 & V>=0
                 Current_Point=Infor(1);
                 Current_Elec=Infor(4);
                 if  (Current_Elec-Distance_min(ID)-Distance(Current_Point+1,ID+1))>=0
                           [Infor,Route] = Add(Infor,Route,ID,Distance,Delivery_P,Time);     
                 else
                        cand=(length(Distance)-99):length(Distance);       
                        indexs=(Current_Elec-Distance(Current_Point+1,end-99:end)>=0);
                         Can_Ele=cand(indexs);
                         DD=Distance(Current_Point+1,Can_Ele)+Distance(Can_Ele,ID+1)';
                         [~,indexs]=min(DD);    
                         Next_Point=Can_Ele(indexs)-1;  
                         %�жϳ��֮���Ƿ��ܷ���ID�̼�
                         if (Current_Time+Time(Current_Point+1,Next_Point+1)+Time(Next_Point+1,ID+1)  +0.5/24)<=Delivery_P(ID+1,8)     
                             [Infor,Route]= Add_Elec( Infor,Route,Next_Point,Distance(Current_Point+1,Next_Point+1),Time(Current_Point+1,Next_Point+1));   
                             [Infor,Route] =Add(Infor,Route,ID,Distance,Delivery_P,Time);
                         else
                                 Falg=0;
                                 break;
                         end     
                 end
             else
                 Falg=0;
                 break;
             end  
    end
    [Infor,Route]=End(Infor,Route,Distance,Time);

       Sum_Cost=+inf;
       if  Falg==1 
             Car_model=Infor(11);%�ó�������
             Wait_Cost=sum(Route(3,:))*576;%�ȴ��ɱ�
             Electric_Cost=Infor(9)*50;%���ɱ�
             Total_Distance=Infor(12);%�ó���ʻ���
            if Car_model==1
                   Transport_Cost=Total_Distance* 0.012;%����ɱ�                    
                    Sum_Cost=200+ Transport_Cost+ Electric_Cost+Wait_Cost;
            else
                   Transport_Cost=Total_Distance* 0.014;         
                   Sum_Cost=300+ Transport_Cost+ Electric_Cost+Wait_Cost;
            end
       end

end
function [Infor,Route] = new_car2(Infor,Route,Car_model,Distance,Time,Delivery_P,ID)
       %1 ��ǰ��   2 ʣ����� 3ʣ���ݻ� 4ʣ����� 5 ������� 6 ����ʱ�� 7 ��Լ���  
       % Current_Point
       %  8��Լ�ݻ� 9������ 10 ��ǰʱ�� 11��������  12 ����ʻ���
       % Infor=[];
       %1 ·��  2 Time_Point  3.Wait_Time

                if Car_model==1
                    Infor(1:12)=[0,2.0,12,100000,0,0.33333333,0,0,0,0.33333333,1,0];
                else
                    Infor(1:12)=[0,2.5,16,120000,0,0.33333333,0,0,0,0.33333333,2,0];
                end

                [Infor,Route] = Add(Infor, Route, ID, Distance, Delivery_P, Time);


                Departure_Time=Infor(6);
                Wait_T=Route(3,:);
        
                Wait_time=Delivery_P(ID+1,7)-(Departure_Time+Time(1,ID+1));
                Wait_time(Wait_time<0)=0;
                %��Ϊ�ǵ�һ�η�������û�еȴ�ʱ��        
                Departure_Time=Departure_Time+Wait_time;      
                Wait_T(end)=0;%���ȴ��ɱ���Ϊ0
                Infor(6)=Departure_Time;
                Route(3,:)=Wait_T;
 end
 
 function [Infor,Route] = Add_Elec(Infor,Route,Next_Point,Distance,Time)       
       %1 ��ǰ��   2 ʣ����� 3ʣ���ݻ� 4ʣ����� 5 ������� 6 ����ʱ�� 7 ��Լ���  
       % Current_Point
       %  8��Լ�ݻ� 9������ 10 ��ǰʱ�� 11��������  12 ����ʻ���
       % Infor=[];
       %1 ·��  2 Time_Point  3.Wait_Time
                Electric_Times=Infor(9);
                Car_model=Infor(11);
                Current_Time=Infor(10);
                Transport_Cost=Infor(12);
                Route_T=Route(1,:);
                Time_T=Route(2,:);
                Wait_T=Route(3,:);
                Route_T=[Route_T Next_Point];%·������           
                Wait_T=[Wait_T 0];
                Transport_Cost=Transport_Cost+Distance;           
                Current_Point=Next_Point;   
                Current_Time= Current_Time+Time+0.5/24;%��ǰʱ����£���30����
                Time_T(end+1)=Current_Time;
                Electric_Times= Electric_Times+1;    %����������
                %���µ���
                if Car_model==1 
                    Current_Elec=100000;
                else
                    Current_Elec=120000;
                end
                Infor(1)=Current_Point;
                Infor(4)=Current_Elec;
                Infor(9)=Electric_Times;
                Infor(10)=Current_Time;
                Infor(12)=Transport_Cost;
                Route=[Route_T;Time_T;Wait_T];
end
            
 function  [Infor,Route] =  Add(Infor, Route,Next_Point,Distance,Delivery_P,Time) %���³�����Ϣ
       %1 ��ǰ��   2 ʣ������ 3ʣ���ݻ� 4ʣ����� 5 ������� 6 ����ʱ�� 7 ��Լ���  
       % Current_Point
       %  8��Լ�ݻ� 9������ 10 ��ǰʱ�� 11��������  12 ����ʻ���
       % Infor=[];
       %1 ·��  2 Time_Point  3.Wait_Time
%                    Current_Elec=Infor(4);
                   Save_W=Infor(7);
                   Save_V=Infor(8);
                   Current_Time=Infor(10);
                   Time_T=Route(2,:);
                   D=Distance( Infor(1)+1,Next_Point+1);
                   T=Time( Infor(1)+1,Next_Point+1);
                   Wait_time=max(Delivery_P(Next_Point+1,7)-(T+Current_Time),0);
                   Route_T=[Route(1,:) Next_Point];
                   Wait_T=[Route(3,:) Wait_time];
                   Delivery=Delivery_P(Next_Point+1,5:6);
                   Time_T(end)=Current_Time;
                   Current_Time= Current_Time+T+Wait_time+0.5/24;
                   Time_T(end+1)=Current_Time;
                  
                  if Delivery_P(Next_Point+1,2)==2
                       Weight=Infor(2)-Delivery(1);%ʣ�����ظ���
                       Volume= Infor(3)-Delivery(2);%ʣ���������
                  else
                            TRoute=Route_T(Delivery_P(Route_T+1,2)==2);                        
                             W=max(Delivery(1)-sum(Delivery_P(TRoute+1,5))+Save_W,0);
                             V=max(Delivery(2)-sum(Delivery_P(TRoute+1,6))+Save_V,0);
                             Weight=Infor(2)-W;%ʣ�����ظ���
                             Volume= Infor(3)-V;%ʣ���������
                             Save_W=Save_W+(Delivery(1)-W);%ȡ���̼ҶԳ�����Լ������
                             Save_V=Save_V+ (Delivery(2)-V);%ȡ���̼ҶԳ�����Լ�����
                  end
                 Infor(1:4)=[Next_Point Weight Volume Infor(4)-D];
                 Infor(7:12)=[Save_W Save_V Infor(9) Current_Time Infor(11)  Infor(12)+D];
                 Route=[Route_T;Time_T;Wait_T];
 end

 
  function [Infor,Route] = End_H(Infor,Route,Distance,Time)
                Current_Point= Infor(1);
                Current_Elec=Infor(4);
                  if  Current_Point~=0
                       if Current_Elec-Distance(Current_Point+1,1)>=0
                          [Infor,Route]=Add_Home(Infor,Route,0,Distance(Current_Point+1,1),Time(Current_Point+1,1));
                      else
                           temp= find(Current_Elec-Distance(Current_Point+1,end-99:end)>=0);
                           temp_point=length(Distance)-100-1+temp;             
                            [~,kk]=min(Distance(Current_Point+1,temp_point+1)+Distance(temp_point+1,1)');
                            Next_Point=temp_point(kk);
                            D1=Distance(Current_Point+1,Next_Point+1);
                            T1=Time(Current_Point+1,Next_Point+1);
                            [Infor,Route]=Add_Elec(Infor,Route,Next_Point,D1,T1);
                            [Infor,Route]=Add_Home(Infor,Route,0,Distance(Current_Point+1,1),Time(Current_Point+1,1));
                      end
                  end      
  end
  
  function [Infor,Route] = Add_Home(Infor,Route,Next_Point,D1,T1)      
                Car_model=Infor(11);
                Current_Time=Infor(10);
                Transport_Cost=Infor(12);
                Route_T=Route(1,:);
                Time_T=Route(2,:);
                Wait_T=Route(3,:);
                Route_T=[Route_T Next_Point];   
                Transport_Cost=Transport_Cost+D1;
                Current_Point=Next_Point;  
                Current_Time= Current_Time+T1+1.0/24;
                Time_T(end+1)=Current_Time;     
                Wait_T=[Wait_T 1.0/24];
                if  Car_model==1
                    Current_Elec=100000;
                    Volume=12;
                    Weight=2.0;                 
                else
                    Current_Elec=120000;
                    Volume=16;
                    Weight=2.5;
                end
                Infor(1:4)=[Current_Point,Weight,Volume,Current_Elec];
                Infor(10)=Current_Time;
                Infor(12)=Transport_Cost;              
                Route=[Route_T;Time_T;Wait_T];
  end
  function [Infor,Route] = End(Infor,Route,Distance,Time)
          Current_Point= Infor(1);
          Current_Elec=Infor(4);
          if  Current_Point~=0
              if Current_Elec-Distance(Current_Point+1,1)>=0
                  [Infor,Route]=Add_Home(Infor,Route,0,Distance(Current_Point+1,1),Time(Current_Point+1,1));
              else
                  temp= find(Current_Elec-Distance(Current_Point+1,end-99:end)>=0);
                  temp_point=length(Distance)-100-1+temp;
                  [~,kk]=min(Distance(Current_Point+1,temp_point+1)+Distance(temp_point+1,1)');
                  Next_Point=temp_point(kk);
                  D1=Distance(Current_Point+1,Next_Point+1);
                  T1=Time(Current_Point+1,Next_Point+1);
                  [Infor,Route]=Add_Elec(Infor,Route,Next_Point,D1,T1);
                  Current_Point= Infor(1);
                  if Current_Point~=0
                      [Infor,Route]=Add_Home(Infor,Route,0,Distance(Current_Point+1,1),Time(Current_Point+1,1));
                  end
              end
          end
          Route(2,end)=Infor(10);
          Route(3,end)=Route(3,end)-1.0/24;
  end